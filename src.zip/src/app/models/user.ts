export class User {

    customerId: string;
    name: string;
}
